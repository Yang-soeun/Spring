package jpabook.jpabook.domain;

public enum DeliveryStatus {
    READY, COMP
}
