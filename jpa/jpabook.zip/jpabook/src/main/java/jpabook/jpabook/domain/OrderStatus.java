package jpabook.jpabook.domain;

public enum OrderStatus {
    ORDER, CANCEL
}
